"strict mode";

// code for time elapse page to put into the console to debug
// let startDate = document.getElementById("dateSelected");
// let endDate = document.getElementById("submitBtn");
// endDate - startDate;


//code to try to get the milliseconds to show up as a summary on the side
// var elapseInfo = { };
// var timeSummary = document.getElementById("elapsedSum");
// function elapsedTimeSummary () {
//     var prop;
//     elapseInfo.document.getElementById("dateSelected");
//     elapseInfo.document.getElementById("submitBtn");
//     for(prop in elapseInfo) {
// 		timeSummary.innerHTML += "<p>" + elapseInfo[prop] + "</p>";
// 	}
// }
// function previewTime() {
// 	elapsedTimeSummary();
// 	document.querySelector("section").style.display = "block";
// 	document.getElementById("elapsedSum").style.display = "block";
// }

// function createEventListener () {
// var Btn = document.getElementById("submitBtn");
// if(Btn.addEventListener) {
//     Btn.addEventListener("click", previewTime, false);
//   } else if (Btn.attachEvent) {
//     Btn.attachEvent("onclick", previewTime);
//  }
// }
// if (window.addEventListener) {
//     window.addEventListener("load", createEventListener, false);
//   } else if (window.attachEvent) {
//     window.attachEvent("onload", createEventListener);
//   }




  //code to try to have the milliseconds show up in a console.log

// function timeElapsed() {
//     document.getElementById("getTime");
// }

// let init = function () {
//     let btn = document.getElementById("submitBtn"),
//     startTime = document.getElementById("submitButton");
//     endTime = new Date();
//     if (btn) {
//         btn.addEventListener('click', () => {
//                 let miliSeconds = new Date() - startTime;

//                 console.log(miliSeconds / 100 + " Seconds.");
//             });
//     }
// }


// document.addEventListener('DOMContentLoaded', () => {
//         init();
//     }, false); 


function timeElapsed() {
  var dateInfo;
  //the line below makes the dateInfo equal to the date selected in the calendar, and essentially converts the variable of dateInfo into a format that can be used in math with the newDate this is issued on the onlclick
  dateInfo = new Date(document.getElementById("dateSelected").value);
  var days;
  days = new Date() - dateInfo;
  console.log(days);

var years = 0;
days = days / (1000 * 60 * 60 * 24) 
while (days > 365) {
    days = days - 365;
    years ++;
}
var months = 0;
while (days > 31) {
  days = days - 31;
  months ++;
}
console.log(Math.floor(days));

}

// print.toString("The elapsed time is " + )




// the function below is how dustin did his, its put in here for reference and for another way to set things up
// function getYearMonth(days)

//         {

//             years = days / (7 * 52);

//             days = days % (7 * 52);

//             months = days / 31;

//             days %= 31;

//             daysLeft = days;

//         }

// the vars are declared way above this part of the code

