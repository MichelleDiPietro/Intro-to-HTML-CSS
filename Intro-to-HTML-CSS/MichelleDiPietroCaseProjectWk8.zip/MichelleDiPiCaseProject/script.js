
// code for subscribe page
const name = document.getElementById("fname");
const form = document.getElementById("form");
const errorElement = document.getElementById("error");

form.addEventListener("submit", (e) => {
    let messages = []
    if (name.value === '' || name.value == null){
        messages.push("Name is required")
    }
    if(messages.length > 0){
        e.preventDefault();
        errorElement.innerText = messages.join(', ')
    }
  
})


// code for time elapse page
// let startDate = document.getElementById("dateSelected");
// let endDate = new Date();
// timeElapsed = (endDate - startDate);
// function timeElapsed() {
//     document.getElementById("getTime");
// }

// let init = function() {
//     let submitBtn = document.querySelector('#item1'),
//     startTime = document.getElementById("dateSelected");
//     if (submitBtn) {
//         submutBtn.addEventListener('click', function() {
//             let miliSeconds = new Date() - startTime;

//             console.log(miliSeconds/100 + " Seconds.");
//         });
//     }
// }

// document.addEventListener('DOMContentLoaded', function() {
//     init();
// }, false); 